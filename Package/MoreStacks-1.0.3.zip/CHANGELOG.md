# Changelog

1.0.3
- Removed some testing code that was causing crashes sometimes

1.0.2
- Removed dynamicStoragePiles dll because pull request was accepted

1.0.1
- Included dynamicStoragePiles dll with compatibility until pull request is accepted

1.0.0
- Release

# Changelog

1.0.1
- Included dynamicStoragePiles dll with compatibility until pull request is accepted

1.0.0
- Release
